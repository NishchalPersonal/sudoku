
boardNumbers = [
    [-1,  2, -1, -1, -1, -1, -1,  8, -1],
    [-1, -1,  5, -1, -1, -1,  3, -1, -1],
    [-1, -1,  9, -1, -1,  2, -1, -1, -1],
    [-1, -1, -1, -1, -1, -1, -1,  3, -1],
    [ 7, -1, -1, -1,  4, -1,  1, -1, -1],
    [-1, -1, -1, -1, -1, -1, -1, -1, -1],
    [-1, -1,  1,  8, -1, -1,  4, -1, -1],
    [-1,  3, -1, -1, -1, -1, -1,  8, -1],
    [-1, -1,  6, -1, -1, -1, -1, -1, -1]
];

function sameBlock(x1, y1, x2, y2) {
    let firstRow = Math.floor(y1 / 3) * 3;
    let firstCol = Math.floor(x1 / 3) * 3;
    return (y2 >= firstRow && y2 <= (firstRow + 2) && x2 >= firstCol && x2 <= (firstCol + 2));
 }
 
 function sameRow(x1, y1, x2, y2) {
    return y1 == y2;
 }
 
 function sameColumn(x1, y1, x2, y2) {
    return x1 == x2;
 }

 /*
window.onload=function running() {
    var palette=document.getElementById("undo");                 
    //createTable(sudokuTable);                                         
    createPallete(palette);                                       
  }*/

  /*
  $(document).on("click", "#board td", function(e) {
    var data = $(this).attr('id');
    alert (data);
});*/

var activeCell = '';
var digitPointer;
var id;
var val;
var testBool;



/*
$(document).on("click", "#undo", function(e) {
    var data = $(this).find('td').attr('id');
    alert (data);
}); 
 */


let sudokuTable = document.getElementById("sudoku");
/*
function checkBoard(){ // check board for same values in rows/columns
    var x;
    var y;

    for(x =0; x < 9; x++){
        var newRows = document.getElementById("sudoku").rows[x];
        for(y =0; y<9; y++){
            var newCell = document.getElementById("sudoku").cells[y];
            lastCell.text('');
        }
        if(sameBlock(x,y,x,y) || sameRow(x,y,x,y) || sameColumn(x,y,x,y)){
            getElementById("sudoku").[x].className = "duplicateDigit";
            getElementById("sudoku").[y].className = "duplicateDigit";

        } 
    }
}*/


$(document).ready(function(){

    let rowElement = $('<tr>');
    let pallete = $('#undo');
    //let reverseButton = document.createElement("img");
    let reverseButton = $('<img>');
    reverseButton.attr("src", "images/undo.png");
    reverseButton.attr("width", "30px");
    reverseButton.attr("height", "30px");

    reverseButton.id = "undo";
    
    let inputId = [1, 2, 3, 4, 5, 6, 7, 8, 9, 'undo'];
    let content = [1, 2, 3, 4, 5, 6, 7, 8, 9, reverseButton];

    /*
    let sudokuTable = document.getElementById("sudoku");

    for(let x =0; x < 9; x++){
        let tableRows = document.createElement("tr");

        tableRows.id = "row" + x;

        sudokuTable.appendChild(tableRows);
        let row = document.getElementById("row" + x);
        for(let y=0; y < 9; y++){
            let rowCell = document.createElement("td");
            row.appendChild(rowCell);
        }
    }*/

    //let sudokuTable = document.getElementById("sudoku");
    let sudokuTable = $('#sudoku');
    //let sudokuTable = document.querySelector("#sudoku").innerHTML;

    for(let x =0; x < boardNumbers.length; x++){
        //let tableRows = document.createElement("tr");
        let tableRows = $('<tr>');
        /*
        tableRows.id = "row" + i;
        sudokuTable.appendChild(tableRows);
        let row = document.getElementById("row" + i);*/
        for(let y=0; y < boardNumbers[x].length; y++){
            //let rowCell = document.createElement("td");
            //document.write(boardNumbers[x][y])
            let rowCell = $('<td>');
            rowCell.id = "id" + ''+x+y;
            if(boardNumbers[x][y] == -1){
                boardNumbers[x][y] = "";
            }
            rowCell.append(boardNumbers[x][y]);
            $(document).on("click", "#sudoku td", function(e){
                $(this).text(digitPointer);
                val = $(this).text(digitPointer);
                lastCell = $(this);

                for(let i =0; i < 9; i++){// same row
                    let sth = document.getElementById("id" +x+i);

                    if(sth.textContent == val){
                        document.getElementById("id" +x+i).className = "error";
                        
                    }
                }

                for(let o =0; o < 9; o++){// same column
                    let sth = document.getElementById("id" +y+o);

                    if(sth.textContent == val){
                        document.getElementById("id" +x+o).className = "error";
                        
                    }
                }

            });
            //row.appendChild(rowCell);
            tableRows.append(rowCell);
        }
        sudokuTable.append(tableRows);
    }



    for(let i = 0; i < content.length; i++){
        let tableData = $('<td>');
        /*
        content.id = "row" + i;
        pallete.appendChild(content);
        let row = document.getElementById("row" + i);*/
        tableData.append(content[i]);
        tableData.attr('id', ''+inputId[i]);
        //tableData.id = "id" + ''+inputId[i];

        /*tableData.onclick = function(){
            activeCell = $(this).attr('id');
            digitPointer = $(this).text();
            val = digitPointer;
        }*/

        $(document).on("click", "#undo td", function(e){
            activeCell = $(this).attr('id');
            //activeCell = this.setattribute("id");
            digitPointer = $(this).text();
            if(activeCell == 'undo'){ // removes the last digit added in the table
                lastCell.text('');
            }
        });
        //td.append(content[i]);
        rowElement.append(tableData);
    }
    pallete.append(rowElement);
});





