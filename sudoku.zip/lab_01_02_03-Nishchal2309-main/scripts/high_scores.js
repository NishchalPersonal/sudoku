const scoreArray = [
    { date: "2021/01/17", duration: "3:41" },
    { date: "2021/01/21", duration: "4:01" },
    { date: "2021/02/01", duration: "2:52" },
    { date: "2021/02/17", duration: "3:08" },
    { date: "2021/03/02", duration: "2:51" },
  ];
  
  function createHighscore(items) {
    const table = document.getElementById("tableContent");
    items.forEach( item => {
      let row = table.insertRow();
      let date = row.insertCell(0);
      date.innerHTML = item.date;
      let duration = row.insertCell(1);
      duration.innerHTML = item.duration;
    });
  }
  createHighscore(scoreArray);
  createHighscore([]);